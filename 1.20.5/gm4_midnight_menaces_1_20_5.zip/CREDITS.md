# Credits

## Creator
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
