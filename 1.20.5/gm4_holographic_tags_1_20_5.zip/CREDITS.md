# Credits

## Creator
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Inspired by
- [SethBling](https://youtube.com/user/SethBling)

## Icon Design
- Hozz
