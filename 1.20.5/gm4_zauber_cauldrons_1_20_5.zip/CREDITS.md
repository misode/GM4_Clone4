# Credits

## Creator
- [Bloo](https://twitter.com/Bloo_dev)

## Updated by
- [Bloo](https://twitter.com/Bloo_dev)
- [Lue](https://github.com/Luexa)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures
- [Memo](https://linktr.ee/miraku_memo)
- [Kyrius](http://discordapp.com/users/287287322360414218)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
