# Credits

## Creators
- InternetAlien
- [SirSheepe](https://twitter.com/SirSheepe)

## Idea By
- [Misode](https://twitter.com/misode_)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
