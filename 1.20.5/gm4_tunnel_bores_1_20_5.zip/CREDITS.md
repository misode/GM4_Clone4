# Credits

## Creator
- [Bloo](https://twitter.com/Bloo_dev)

## Updated by
- [Bloo](https://twitter.com/Bloo_dev)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- Hozz
