# Credits

## Creator
- [Denniss](https://twitter.com/Dennis2p_)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
