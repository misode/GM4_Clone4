# Credits

## Creator
- Kattacka

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
