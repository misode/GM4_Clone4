# Credits

## Creators
- [Sparks](https://twitter.com/SelcouthSparks)
- [SiberianHat](https://twitter.com/SiberianHat)

## Updated by
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [Kruthers](https://twitter.com/Pandakruthers)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
