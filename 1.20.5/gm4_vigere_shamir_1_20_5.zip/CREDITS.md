# Credits

## Creator
- [Thanathor](https://twitter.com/The_Thanathor)
- TheEpyonProject

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
