# Credits

## Creators
- [Sparks](https://twitter.com/SelcouthSparks)
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [Bloo](https://twitter.com/Bloo_dev)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
- [SirSheepe](https://twitter.com/SirSheepe)

## Updated by
- [Denniss](https://twitter.com/Dennis2p_)
- [Misode](https://twitter.com/misode_)
- [MichaelMiner137](https://linktr.ee/MichaelMiner137)
- TheEpyonProject

## Textures by
- [Memo](https://linktr.ee/miraku_memo)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
