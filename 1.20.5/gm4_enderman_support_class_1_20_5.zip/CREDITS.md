# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
