# Credits

## Creators
- [Bloo](https://twitter.com/Bloo_dev)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
