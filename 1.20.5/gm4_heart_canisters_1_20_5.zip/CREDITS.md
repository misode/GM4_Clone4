# Credits

## Creators
- [Sparks](https://twitter.com/SelcouthSparks)
- SpiderRobotMan

## Updated by
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [Misode](https://twitter.com/misode_)
- TheEpyonProject

## Textures by
- Jonpot

## Icon Design
- Hozz
