# calculate modifiers for newly spawned cave spider
# @s = cave spider
# at @s
# run from mob/initiate

# base stat nerf
attribute @s generic.max_health modifier add e94edf94-a98a-4dcc-bb23-2b59890663fd gm4_ce_base_health_nerf -4 add
attribute @s generic.attack_damage modifier add 3182427e-beb4-4f9a-9f39-674baf1d5ee4 gm4_ce_base_damage_nerf -1 add
attribute @s generic.movement_speed modifier add 811e516b-a6b2-40e4-b56e-0ffd7173297b gm4_ce_base_speed_nerf -0.04 multiply_base

# calculate stats based on difficulty
scoreboard players operation $mob_stats gm4_ce_data += $difficulty gm4_ce_data
execute if score $difficulty gm4_ce_data matches 4.. run scoreboard players add $mob_speed gm4_ce_data 2
execute if score $difficulty gm4_ce_data matches 11.. run scoreboard players add $mob_speed gm4_ce_data 6

# biome specific modifiers for this mob
effect give @s[predicate=gm4_combat_expanded:mob/modifier/mountainous] jump_boost infinite 1
effect give @s[predicate=gm4_combat_expanded:mob/modifier/burned, predicate=gm4_combat_expanded:technical/chance/spider_fire_resist] fire_resistance infinite 0
execute if predicate gm4_combat_expanded:mob/modifier/lush_caves run function gm4_combat_expanded:mob/effect/lush_caves_spider
tag @s[predicate=gm4_combat_expanded:mob/modifier/toxic] add gm4_ce_poison_bite
execute if entity @s[tag=!gm4_ce_extra_mob, predicate=gm4_combat_expanded:mob/modifier/growth] store success score $mob_extras gm4_ce_data run summon cave_spider ~ ~ ~ {Tags:["gm4_ce_extra_mob"]}
execute if entity @s[tag=!gm4_ce_extra_mob, predicate=gm4_combat_expanded:mob/modifier/growth, predicate=gm4_combat_expanded:technical/chance/extra_spider_spawn] store success score $mob_extras gm4_ce_data run summon cave_spider ~ ~ ~ {Tags:["gm4_ce_extra_mob"]}

# set modifiers
function gm4_combat_expanded:mob/modifier/prep
