# tag spore item as spore
# @s = spore item
# at unspecified
# run from mob/effect/spores/check

tag @s add gm4_ce_spore
data merge entity @s {Age:-32768,PickupDelay:32767,Motion:[0.0d,-1.0d,0.0d]}
