#@s = all players at @s
#run from main

execute anchored eyes positioned ^ ^ ^0.5 positioned ~ ~-0.5 ~ if entity @e[distance=..1, type=command_block_minecart, tag=gm4_liquid_minecart, limit=1, sort=nearest] run function gm4_liquid_minecarts:level_report
execute unless entity @s[tag=gm4_lt_found_tank] anchored eyes positioned ^ ^ ^1.5 positioned ~ ~-0.5 ~ if entity @e[distance=..0.5, type=command_block_minecart, tag=gm4_liquid_minecart, limit=1, sort=nearest] run function gm4_liquid_minecarts:level_report
execute unless entity @s[tag=gm4_lt_found_tank] anchored eyes positioned ^ ^ ^2.5 positioned ~ ~-0.5 ~ if entity @e[distance=..0.5, type=command_block_minecart, tag=gm4_liquid_minecart, limit=1, sort=nearest] run function gm4_liquid_minecarts:level_report
execute unless entity @s[tag=gm4_lt_found_tank] anchored eyes positioned ^ ^ ^3.5 positioned ~ ~-0.5 ~ if entity @e[distance=..0.5, type=command_block_minecart, tag=gm4_liquid_minecart, limit=1, sort=nearest] run function gm4_liquid_minecarts:level_report

tag @s remove gm4_lt_found_tank
