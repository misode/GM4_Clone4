scoreboard objectives add gm4_crafting dummy
scoreboard objectives add gm4_count dummy
schedule function gm4_custom_crafters-3.1:main 1
execute if entity @e[type=armor_stand, tag=gm4_custom_crafter_stand] run scoreboard players set custom_crafters gm4_earliest_version 300000
execute if score gm4_guidebook load.status matches 1 unless entity @e[type=marker, tag=gm4_guide, name="\"gm4_custom_crafters_guide\"", limit=1] run summon marker ~ 783.392311518527 ~ {CustomName: '"gm4_custom_crafters_guide"', Tags: ["gm4_guide"], data: {type: "base", expansions: [], id: "custom_crafters", page_count: 3, line_count: 1, module_name: "Custom Crafters"}}
execute unless score custom_crafters gm4_earliest_version matches ..301005 run scoreboard players set custom_crafters gm4_earliest_version 301005


data modify storage gm4:log versions append value {id:"gm4_custom_crafters",module:"lib_custom_crafters",version:"3.1.X",from:"Mountaineering"}
