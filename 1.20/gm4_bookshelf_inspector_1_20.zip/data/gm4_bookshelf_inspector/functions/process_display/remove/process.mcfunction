# text_display removing tick clock
# @s = removing text_display
# at unspecified
# run from process_display/remove/tick

scoreboard players add @s gm4_bookshelf_inspector_display_state 1

execute if score @s gm4_bookshelf_inspector_display_state matches 6 run data merge entity @s {start_interpolation:-1,interpolation_duration:3,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,0.0f,0.0f],scale:[0.0f,0.0f,0.0f]}}
execute if score @s gm4_bookshelf_inspector_display_state matches 8 run kill @s
