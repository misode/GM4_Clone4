#@s = bone item on the ground
#at @s
#called by event

summon skeleton ~ ~ ~ {DeathLootTable:"minecraft:empty",ArmorItems:[],HandItems:[],ActiveEffects:[{Id:9,Amplifier:1,Duration:30}],Attributes:[{Name:"generic.attack_damage",Base:10.0d}]}

playsound block.redstone_torch.burnout hostile @a[distance=..16] ~ ~ ~ 1 0.1
function gm4_resurrecting_skeletons:absorb_bone
