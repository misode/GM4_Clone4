execute if score gm4_brewing load.status matches 1 unless score gm4_brewing_minor load.status matches 1.. run scoreboard players set gm4_brewing_minor load.status 1

execute unless score gm4_brewing load.status matches 1.. run scoreboard players set gm4_brewing_minor load.status 1
execute unless score gm4_brewing load.status matches 1.. run scoreboard players set gm4_brewing load.status 1
